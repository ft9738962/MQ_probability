from setuptools import setup

setup(name='MQprobability',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['MQprobability'],
      author = 'Max Qiu',
      author_webpage = 'https://github.com/ft9738962',
      zip_safe=False)
